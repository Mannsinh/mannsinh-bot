b2s_dlg : dialog {
  label = "B2S - Block Library & Swapper";
  spacer;
  : row {
    : list_box { label = "Blocks in Bundle:"; key = "lb_blocks"; height = 14; width = 26; }
    : boxed_column {
      label = "Preview";
      : image { key = "img_preview"; width = 28; height = 12; color = -2; }
    }
  }
  spacer;
  : row {
    : button { label = "Place Multiple"; key = "btn_place"; is_default = true; }
    : button { label = "Swap Existing"; key = "btn_swap"; }
    : button { label = "Save New"; key = "btn_save"; }
    : button { label = "Delete Block"; key = "btn_del"; }
    : cancel_button { label = "Close"; }
  }
}
